$(document).ready(function () {
    const searchIcon = $('.searchIcon')
    const width = $(window).width()

    if (width < 960) {
        

    }

})

